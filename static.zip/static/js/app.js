console.log('QR Parking System loaded');
